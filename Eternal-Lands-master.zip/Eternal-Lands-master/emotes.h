#ifndef __EMOTES_H__
#define __EMOTES_H__

extern int emotes_menu_x;
extern int emotes_menu_y;
extern int emotes_win;

void display_emotes_menu(void);
void send_emote(int emote_id);

#endif

