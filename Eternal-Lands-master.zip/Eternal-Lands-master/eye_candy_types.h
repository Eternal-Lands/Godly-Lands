/*
 * eye_candy_types.h
 *
 *  Created on: 17.11.2008
 *      Author: lindner
 */

#ifndef EYE_CANDY_TYPES_H_
#define EYE_CANDY_TYPES_H_

typedef void* ec_reference;
typedef void* ec_bounds;
typedef void* ec_effects;

#endif /* EYE_CANDY_TYPES_H_ */
