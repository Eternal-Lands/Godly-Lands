#ifndef __EYE_CANDY_DEBUGWIN__
#define __EYE_CANDY_DEBUGWIN__

extern int ecdebug_win;

void display_ecdebugwin();

#endif // EYE_CANDY_DEBUGWIN
