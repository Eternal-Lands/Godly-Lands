#ifndef __makeargv_h__
#define __makeargv_h__

int makeargv( char *string, char ***argv );
void freemakeargv(char **argv);

#endif
