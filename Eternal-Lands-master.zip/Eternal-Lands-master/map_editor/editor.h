#ifndef __EDITOR_H__
#define __EDITOR_H__

extern char exec_path[256];
extern char heights_3d;
extern char minimap_on;
extern int new_map_menu;
extern char view_grid;
extern int show_mapeditor_reflections;

#endif
