#ifndef __LANSELWIN_H__
#define __LANSELWIN_H__

#ifdef __cplusplus
extern "C" {
#endif

int display_langsel_win(void);
extern int langsel_rootwin;
extern int have_saved_langsel;

#ifdef __cplusplus
} // extern "C"
#endif

#endif
